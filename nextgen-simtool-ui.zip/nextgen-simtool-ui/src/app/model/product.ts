export class Product {
  name: string;
  messageTypes: [];
}
