export class ConfigParams {
  messageType: string;
  paths: string[];
  searchKeywords: string[];
  productName: string;
  isDefault: string;
  partnerId: string;
  contentType: string;
  payload: string;
  searchValue: string;

  constructor(messageType: string,
              paths: string[],
              searchKeywords: string[],
              productName: string,
              isDefault: string,
              partnerId: string,
              contentType: string,
              payload: string,
              searchValue: string)
  {
    this.messageType = messageType;
    this.paths = paths;
    this.searchKeywords = searchKeywords;
    this.productName = productName;
    this.partnerId = partnerId;
    this.contentType = contentType;
    this.payload = payload;
    this.isDefault = isDefault;
    this.searchValue = searchValue;
  }
}
