export class MessageType {
  messageType: string;
}
