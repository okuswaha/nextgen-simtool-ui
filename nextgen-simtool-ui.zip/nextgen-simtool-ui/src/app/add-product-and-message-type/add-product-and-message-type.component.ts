import { Component, OnInit } from '@angular/core';
import {ConfigParams} from "../model/configParams";
import {ProductServiceService} from "../service/product-service.service";

@Component({
  selector: 'app-add-product-and-message-type',
  templateUrl: './add-product-and-message-type.component.html'
})
export class AddProductAndMessageTypeComponent implements OnInit {

  configParams: ConfigParams;
  messageType: string;
  paths: string[] = [];
  searchKeywords: string[] = [];
  productName: string;
  isDefault: string;
  partnerId: string;
  contentType: string;
  payload: string;
  searchValue: string;



  constructor(private productService: ProductServiceService) { }

  ngOnInit() {

  }

  onSubmit(productForm) {
    console.log(productForm.searchKeyword);

    this.productName = productForm.value.productName;
    this.messageType = productForm.value.messageType;
    this.paths.push(productForm.value.path);
    this.searchKeywords.push(productForm.value.searchKeyword);

    this.configParams = new ConfigParams(this.messageType,
    this.paths,
    this.searchKeywords,
    this.productName,
    "",
    "",
    "",
    "",
    "");
    this.productService.saveNewProduct(this.configParams).subscribe( configData => {
      window.location.reload();
    })

  }

}
