import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {ConfigParams} from "../model/configParams";
import {ProductServiceService} from "../service/product-service.service";
import { ActivatedRoute, Router } from '@angular/router';
import {HttpHeaders} from "@angular/common/http";
import {SimulationData} from "../model/simulationData";

@Component({
  selector: 'app-config-parameters',
  templateUrl: './config-parameters.component.html',
  styleUrls: ['./config-parameters.component.scss']
})
export class ConfigParametersComponent implements  OnInit{

  @Input() loadConfigParams: ConfigParams;
  fileToUpload: File = null;
  isDefault: string = "false";
  searchValue: string;
  searchKeyValue: string;
  path: string;
  partnerId: string;
  result: string;
  contentType: string;
  fileName: string;
  stimulationobj: SimulationData;
  disabledProperty: boolean = false;
  defaultCheckbox: string = "";
  fileLabelName: string = "No file Choosen";
  simulationDataList: SimulationData[];


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productService: ProductServiceService) {
  }

  ngOnInit(){}

  onFileChange(files: FileList) {
    if (files.length > 1) {

      return false;
    }

    this.fileToUpload = files.item(0);
    this.fileLabelName = this.fileToUpload.name;
  }

  import(): void {
    this.fileName = this.fileToUpload.name
    this.contentType = this.fileToUpload.name.split(".")[1];
    let fileReader = new FileReader();
    fileReader.onload = (e) => {
      this.result = fileReader.result.toString();
      this.constructJson();
    }
    fileReader.readAsText(this.fileToUpload);

  }

  getCheckBoxValue() {
    if (this.defaultCheckbox) {
      this.searchKeyValue = "";
      this.searchValue = "";
      this.disabledProperty = true;
    } else {
      this.disabledProperty = false;
    }
    this.isDefault = this.defaultCheckbox ? "true": "false";

  }
  getSearchValue(event) {
    if (this.isDefault = "true") {
      this.getCheckBoxValue();
    }
    this.searchValue = event.target.value;
  }

  getSearchKeyValue(event) {
    if (this.isDefault = "true") {
      this.getCheckBoxValue();
    }
    this.searchKeyValue = event.target.value;
  }
  getPatnerKeyValue(event) {
    if (this.isDefault = "true") {
      this.getCheckBoxValue();
    }
    this.partnerId = event.target.value;
  }

  getPathValue(event) {
    if (this.isDefault = "true") {
      this.getCheckBoxValue();
    }
    this.path = event.target.value;
  }

  @Output() simulationEvent = new EventEmitter();

  constructJson () {
    this.stimulationobj = new SimulationData(
      this.loadConfigParams.messageType,
      this.path,
      this.searchKeyValue,
      this.loadConfigParams.productName,
      this.isDefault,
      this.partnerId,
      this.contentType,
      this.result,
      this.searchValue,
      this.fileName);
    this.productService.save(this.stimulationobj).subscribe( configData => {
      this.stimulationobj = configData;
      this.simulationEvent.emit(configData);
        this.path = "";
        this.searchValue = "";
        this.searchKeyValue = "";
        this.isDefault =""
        this.partnerId ="";
        this.contentType = "";
        this.result = "";
        this.searchValue = "";
        this.fileName = "";
        this.fileLabelName = "";
    });
  }
}
