import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Product} from './model/product';
import {ProductServiceService} from './service/product-service.service';
import {ConfigParams} from "./model/configParams";
import {SimulationData} from "./model/simulationData";
import {animate, keyframes, query, stagger, state, style, transition, trigger} from "@angular/animations";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('simulations', [
      transition('* => *' , [
        query(':enter', style({opacity: 0}), {optional: true}),
        query(':enter', stagger('300ms',[
          animate('.6s ease-in', keyframes([
            style({opacity:0, transform:'translateY(-75%)', offset:0}),
            style({opacity:.5, transform:'translateY(35%)', offset:.3}),
            style({opacity:1, transform:'translateY(0%)', offset:1}),
          ]))
        ]), {optional: true})
      ])
    ])]
})
export class AppComponent implements OnInit {

  title: string;

  product: Product[];
  configParams: ConfigParams;
  messageType: String;
  loadComponent: boolean;
  loadJumbotron: boolean;
  fileToUpload: File = null;
  fileText: string;
  configParamsTo: ConfigParams;
  addProductMessageType: boolean;
  simulationData: boolean;
  simulationDataList : SimulationData[] = [];
  selected :any;

  constructor(private productService: ProductServiceService) {

  }

  ngOnInit() {
    this.loadJumbotron = true;
    this.productService.getProducts().subscribe(data => {
      this.product = data;
    });
  }

  getConfigParams (event, productName, messageType){
    this.loadComponent = true;
    this.loadJumbotron = false;
    this.simulationData = false;
    this.addProductMessageType = false;
    this.selected = messageType;
    this.productService.getConfigurableParamsByMessageType(productName, messageType).subscribe( configData => {
      this.configParams = configData;
    });

    this.productService.getConfigParamsList(productName, messageType).subscribe( simulationdData => {
      this.simulationDataList = simulationdData;
      if (simulationdData.length > 0 ) {
        this.simulationData = true;
      }
    });
  }

  pushDataToList(event) {
    this.simulationDataList.push(event);
    if (this.simulationDataList.length > 0) {
      this.simulationData = true;
    }
  }

  onClick(event) {
    this.loadComponent = false;
    this.loadJumbotron = false;
    this.simulationData = false;
    this.addProductMessageType = true;
  }
  isActive(messageType) {
    return this.selected==messageType;
  }
}
